package modelo.dominio;

public class Funcionario {
	private String nome, cpf, matricula, sexo;

	public Funcionario(String nome, String cpf, String matricula, String sexo) {
		super();
		this.nome = nome;
		this.cpf = cpf;
		this.matricula = matricula;
		this.sexo = sexo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	
}
