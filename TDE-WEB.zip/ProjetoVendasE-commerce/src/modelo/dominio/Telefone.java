package modelo.dominio;

public class Telefone {
	private String tel;

	public Telefone(String tel) {
		super();
		this.tel = tel;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}
	
}
