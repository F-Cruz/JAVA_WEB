package modelo.dominio;

public class Produto {
	private int codigo, qtd;
	private String tipoProduto;
	public Produto(int codigo, int qtd, String tipoProduto) {
		super();
		this.codigo = codigo;
		this.qtd = qtd;
		this.tipoProduto = tipoProduto;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public int getQtd() {
		return qtd;
	}
	public void setQtd(int qtd) {
		this.qtd = qtd;
	}
	public String getTipoProduto() {
		return tipoProduto;
	}
	public void setTipoProduto(String tipoProduto) {
		this.tipoProduto = tipoProduto;
	}
	
}
