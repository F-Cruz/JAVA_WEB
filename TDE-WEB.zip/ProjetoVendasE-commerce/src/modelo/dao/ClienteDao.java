package modelo.dao;

import java.util.List;

import javax.persistence.EntityManager;

import modelo.dominio.Cliente;

public class ClienteDao {

	private EntityManager manager;

	public ClienteDao() {
		super();

		this.manager = JPAUtil.getEntityManager();
	}

	public Cliente salvar(Cliente cli) {
		this.manager.getTransaction().begin();
		cli = this.manager.merge(cli);
		this.manager.getTransaction().commit();
		return cli;
	}

	public void excluir(Cliente cli) {
		this.manager.getTransaction().begin();
		this.manager.remove(cli);
		this.manager.getTransaction().commit();
	}

	public Cliente obter(Integer codigo) {
		return this.manager.find(Cliente.class, codigo);
	}

	public List<Cliente> listar() {

		String jpql = "from Cliente c  order by c.nome";

		List<Cliente> lista = this.manager.createQuery(jpql, Cliente.class).getResultList();

		return lista;
	}

}
