package modelo.dao;

import javax.persistence.EntityManager;

import modelo.dominio.Endereco;



public class EnderecoDao {
	private EntityManager manager;

	public EnderecoDao() {
		super();

		this.manager = JPAUtil.getEntityManager();
	}

	public Endereco salvar(Endereco ende) {
		this.manager.getTransaction().begin();
		ende = this.manager.merge(ende);
		this.manager.getTransaction().commit();
		return ende;
	}

	public void excluir(Endereco ende) {
		this.manager.getTransaction().begin();
		this.manager.remove(ende);
		this.manager.getTransaction().commit();
	}

	public Endereco obter(Integer codigo) {
		return this.manager.find(Endereco.class, codigo);
	}


}
