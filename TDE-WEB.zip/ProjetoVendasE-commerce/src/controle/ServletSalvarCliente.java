package controle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.dao.ClienteDao;
import modelo.dominio.Cliente;

/**
 * Servlet implementation class ServletSalvarCliente
 */
@WebServlet(name = "salvarCliente", urlPatterns = { "/salvarCliente" })
public class ServletSalvarCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServletSalvarCliente() {
		super();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.sendError(403, "Acesso proibido para método GET. Use o formulário para enviar.");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<String> erros = new ArrayList<String>();
		String codigoStr = request.getParameter("codigo");
		String nome = request.getParameter("nome");
		String email = request.getParameter("email");
		String cpf = request.getParameter("cpf");
		String sexo = request.getParameter("sexo");
		String idadeStr = request.getParameter("idade");
		
		Integer idade;
		try {
			idade = Integer.parseInt(idadeStr);
		} catch (NumberFormatException e) {
			idade = null;
		}
		Integer codigo;
		try {
			codigo = Integer.parseInt(codigoStr);
		} catch (NumberFormatException e) {
			codigo = null;
		}
				
				if (nome == null || nome.trim().length() == 0)
					erros.add("O campo nome é obrigatório.");
				
				if (email == null || email.trim().length() == 0)
					erros.add("O Campo email esta invalido");
				
				if (sexo == null || sexo.trim().length() == 0)
					erros.add("O Campo sexo esta invalido");
				if (idade == null )
					erros.add("O Campo idade esta invalido");
				
				
				ClienteDao dao = new ClienteDao();

				
				Cliente cli = null;
				if (codigo == null)
					cli = new Cliente(); 
				else
					cli = dao.obter(codigo); 

				cli.setNome(nome);
				cli.setEmail(email);
				cli.setCpf(cpf);
				cli.setSexo(sexo);
				cli.setIdade(idade);
				
			
				if (erros.size() == 0)
				{
				
					dao.salvar(cli);


					response.sendRedirect("abrirPaginaCliente");
				}
				else
				{
				
					request.setAttribute("cli", cli);
					request.setAttribute("erros", erros);
					
			

					
			
					RequestDispatcher desp = request.getRequestDispatcher("paginaCliente.jsp");
				
					desp.forward(request, response);
				}
				
			}

}
